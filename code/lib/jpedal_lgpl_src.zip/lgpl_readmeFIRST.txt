This the source code for the LGPL version of JPedal - a cutdown viewer from the full JPedal library

To compile the code, you will also need to download these jars and place in your build.dir (jai_core.jar,jai_codec.jar,bcmail.jar,bcprov.jar)
Details on getting the jars can be found at http://www.jpedal.org/support_AddJars.php

The src directory contains the source code building JPedal (LGPL version). It is supplied without
any warranty or support.

Additional JAR files required for compilation can be found at: http://www.jpedal.org/download/lgpl/jpedal_lgpl_library.zip

If you wish to use JPedal (or any part) in a LGPL product, you merely need to ensure you
fully comply with the LGPL license.


The enhanced commercial version is supported and fully tested by IDRsolutions

IDRsolutions
July 2012
